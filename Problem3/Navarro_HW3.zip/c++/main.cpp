//MALCOLM NAVARRO
//CIS554 - OOP c++
//main.cpp
//MAIL FILE CALLING THE CAI OBJECT TO START TESTING STUDENT

#include <iostream>
#include "CAI.h"
using namespace std;

int main()
{
  //INIT CAI OBJ + START TESTING
  CAI c;
  c.startTest();

  return 0;
}
