//MALCOLM NAVARRO
//CIS554 - OOP c++
//convert.h
//This is the header file for the Convert class which provides the 
//public method convertToDec. Simple.

class Convert
{
	public:
		int convertToDec(int, int);
		
};
